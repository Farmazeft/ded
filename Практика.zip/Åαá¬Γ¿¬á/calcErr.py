import numpy as np
from time import time
from numpy.linalg import inv
dir = 's:/Study/Practice/alltxt/'
import math

massQ = []
massP = []
massT1 = []
massT = []
massV = []
Y = []
Y2 = []

mass = [massP, massQ, massT, massT1, massV, Y]
X = []
Xdop = []


def calcErr(q, p, t1, t, v, t2):
    massParams = [q, p, t1, t, v, t2]
    for i in range(len(massParams)):
        f = open(massParams[i])
        line = f.readline()
        while line:
            line = line.replace('\n', '')
            line = line.replace('\t', ' ')
            line = line.replace(',', '.')
            j = line.index(' ')
            line = float(line[j + 1:])
            mass[i].append(line)
            line = f.readline()
        f.close()

    for i in range(13152):
        X.append({'Q': massQ[i], 'P': massP[i], 'T1': massT1[i], 'T': massT[i], 'V': massV[i]})
        Xdop.append([massQ[i], massP[i], massT1[i], massT[i], massV[i]])


calcErr(dir+'Q110.txt', dir+'P110.txt', dir+'T111.txt', dir+'T010.txt', dir+'V110.txt', dir+'T112.txt')

#  A = (X^T * X)^(-1) * X^T * Y

Xdop = np.array(Xdop)
#print("Mass Xdop:\n", Xdop)

Xdop_t = np.array(Xdop.transpose())
# print("Mass-t:\n", Xdop_t)

X_res = np.array(np.dot(Xdop_t, Xdop))
# print(X_res)
X_res = inv(X_res)
# print("Mass-inv:\n", X_res)

X_final = np.dot(np.dot(X_res, Xdop_t), Y)
print('Koef:\n', X_final)
sumY2 = 0
for i in range(len(Xdop)):
    Y2.append(Xdop[i][0]*X_final[0] + Xdop[i][1]*X_final[1] + Xdop[i][2]*X_final[2] + Xdop[i][3]*X_final[3] + Xdop[i][4]*X_final[4])


for i in range(len(Y2)):
    sumY2 += Y2[i]

print(sumY2)

sumY = 0

for i in range(len(Y)):
    sumY += Y[i]

print(sumY)

error1 = abs(sumY2-sumY)

print (error1)


def Ten(q, p, t1, t, v,):
    return math.sqrt(q^2 + p^2 + (t1^2) + t^2 + v^2)

Xdops = []

for i in range(len(Xdop)):
    Xdops.append({"item":math.sqrt(pow(Xdop[i][0],2)+pow(Xdop[i][1],2)+pow(Xdop[i][2],2)+pow(Xdop[i][3],2)+pow(Xdop[i][4],2)),"index":i})
print (Xdops)
n = 1
print (Xdops[0]['item'])

print('processing...')
start = time()
while n < len(Xdops):
    for i in range(len(Xdops)-n):
        if Xdops[i]['item'] > Xdops[i+1]['item']:
            a = Xdops[i]
            Xdops[i] = Xdops[i+1]
            Xdops[i+1] = a
    n+=1
stop = time()
print("Worktime: " + str(int(stop-start)))
print (Xdops)
print(Xdops[0])


Xdops_ten = []
#lens = (51, 3239, 6, 53, 15)
lens = 102
for i in range(len(Xdops)-1):
    if((Xdops[i]['item'] <= lens) & (Xdops[i+1]['item'] >  lens)):
        Xdops_ten.append(Xdops[i - 4])
        Xdops_ten.append(Xdops[i - 3])
        Xdops_ten.append(Xdops[i - 2])
        Xdops_ten.append(Xdops[i - 1])
        Xdops_ten.append(Xdops[i])
        Xdops_ten.append(Xdops[i + 1])
        Xdops_ten.append(Xdops[i + 2])
        Xdops_ten.append(Xdops[i + 3])
        Xdops_ten.append(Xdops[i + 3])
        Xdops_ten.append(Xdops[i + 5])
        break

print ("Mass - 10: ")
print (Xdops_ten)
sum = 0

for i in range(len(Xdops_ten)):
    sum += Xdops[i]['item']

error2 = sum/10
print (error2)
print (error1)
