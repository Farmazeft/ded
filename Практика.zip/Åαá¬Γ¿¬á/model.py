import numpy as np
from numpy.linalg import inv
import math
dir = '/home/mario/Desktop/Sum_project/alltxt/'

massQ = []#расход
massP = []#давление перед УОГ
massT1 = []#температура на входе УОГ
massT = []#температура воздуха
massV = []# массив включенных вентиляторов
Y = []# это массив выходных значений
Y2 = []# это Y*. то есть если мы умножим строку из Xdop на A(коэффициенты)

mass = [massP, massQ, massT, massT1, massV, Y]
X = []
Xdop = []


def calcErr(q, p, t1, t, v, t2):# перемещаем файлы в массивы
    massParams = [q, p, t1, t, v, t2]
    for i in range(len(massParams)):
        f = open(massParams[i])
        line = f.readline()
        while line:
            line = line.replace('\n', '')
            line = line.replace('\t', ' ')
            line = line.replace(',', '.')
            j = line.index(' ')
            line = float(line[j + 1:])
            mass[i].append(line)
            line = f.readline()
        f.close()

    for i in range(13152):#заменить на длинну файла
        X.append({'Q': massQ[i], 'P': massP[i], 'T1': massT1[i], 'T': massT[i], 'V': massV[i]})
        Xdop.append([massQ[i], massP[i], massT1[i], massT[i], massV[i]])


calcErr(dir+'Q110.txt', dir+'P110.txt', dir+'T111.txt', dir+'T010.txt', dir+'V110.txt', dir+'T112.txt')#вызываем функцию по заполнению массива

#  A = (X^T * X)^(-1) * X^T * Y

Xdop = np.array(Xdop)#обычный массив
#print("Mass Xdop:\n", Xdop)

Xdop_t = np.array(Xdop.transpose())#транспонированный массив
# print("Mass-t:\n", Xdop_t)

X_res = np.array(np.dot(Xdop_t, Xdop))
# print(X_res)
X_res = inv(X_res)#инвертированный массив
# print("Mass-inv:\n", X_res)

А = np.dot(np.dot(X_res, Xdop_t), Y)#Массив коэффициентов А
print('Koef:\n', А)

sumY2 = 0#сумма элементов Y*
for i in range(len(Xdop)):
    Y2.append(Xdop[i][0]*А[0] + Xdop[i][1]*А[1] + Xdop[i][2]*А[2] + Xdop[i][3]*А[3] + Xdop[i][4]*А[4])
    

for i in range(len(Y2)):
    sumY2 += Y2[i]

sumY = 0#сумма элементов Y

for i in range(len(Y)):
    sumY += Y[i]

error1 = abs(sumY2-sumY)#ошибка при первом методе

def Ten(q, p, t1, t, v):#функция которая считает длинну вектора который мы подаем на вход
    return math.sqrt(q^2 + p^2 + (t1^2) + t^2 + v^2)

Xdops = []#массив длинн векторов с индексами векторов(чтобы потом обратно выбрать нужные вектора)

for i in range(len(Xdop)):
    Xdops.append({"item":math.sqrt(pow(Xdop[i][0],2)+pow(Xdop[i][1],2)+pow(Xdop[i][2],2)+pow(Xdop[i][3],2)+pow(Xdop[i][4],2)),"index":i})

n = 1#пузырьковая сортировка массива(работает медленно)
print (Xdops[0]['item'])
while n < len(Xdops):
    for i in range(len(Xdops)-n):
        if Xdops[i]['item'] > Xdops[i+1]['item']:
            a = Xdops[i]
            Xdops[i] = Xdops[i+1]
            Xdops[i+1] = a
    n+=1

Xdops_ten = []#массив в который потом поместим 10 ближайших точек
#lens = (51, 3239, 6, 53, 15)
lens = 102#вместо числа вызвать функцию с нужными аргумментами
for i in range(len(Xdops)-5):# ено если число будет среди первых чисел то программа покрашиться, но чтобы переделать нужно много думать
    if((Xdops[i]['item'] <= lens) & (Xdops[i+1]['item'] >  lens)):#заполняем массив из 10 ближайших точек
        Xdops_ten.append(Xdops[i - 4])
        Xdops_ten.append(Xdops[i - 3])
        Xdops_ten.append(Xdops[i - 2])
        Xdops_ten.append(Xdops[i - 1])
        Xdops_ten.append(Xdops[i])
        Xdops_ten.append(Xdops[i + 1])
        Xdops_ten.append(Xdops[i + 2])
        Xdops_ten.append(Xdops[i + 3])
        Xdops_ten.append(Xdops[i + 3])
        Xdops_ten.append(Xdops[i + 5])
        break

print ("Mass - 10: ")

error2 = 0# ошибка при втором методе
for i in range(len(Xdops_ten)):
    error2 += Xdops[i]['item']

print ("Ошибка при 1 методе:")
print (error1)
print ("Ошибка при 2 методе:")
print (error2)